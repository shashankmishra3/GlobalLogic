/**
 * 
 */
/**
 * @author shashank.mishra3
 *
 */
module BookDemo {
	requires java.sql;
}